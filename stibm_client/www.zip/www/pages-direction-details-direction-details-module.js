(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-direction-details-direction-details-module"],{

/***/ "./src/app/pages/direction-details/direction-details.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/pages/direction-details/direction-details.module.ts ***!
  \*********************************************************************/
/*! exports provided: DirectionDetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DirectionDetailsPageModule", function() { return DirectionDetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _direction_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./direction-details.page */ "./src/app/pages/direction-details/direction-details.page.ts");







var routes = [
    {
        path: '',
        component: _direction_details_page__WEBPACK_IMPORTED_MODULE_6__["DirectionDetailsPage"]
    }
];
var DirectionDetailsPageModule = /** @class */ (function () {
    function DirectionDetailsPageModule() {
    }
    DirectionDetailsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_direction_details_page__WEBPACK_IMPORTED_MODULE_6__["DirectionDetailsPage"]]
        })
    ], DirectionDetailsPageModule);
    return DirectionDetailsPageModule;
}());



/***/ }),

/***/ "./src/app/pages/direction-details/direction-details.page.html":
/*!*********************************************************************!*\
  !*** ./src/app/pages/direction-details/direction-details.page.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<style>\n  \n  ion-col > div {\n    /* background-color: #f7f7f7; */\n    /*border: solid 1px #ddd;*/\n    padding: 10px;\n    border-radius: 5px;\n    margin-left: 5px;\n    margin-right: 5px;\n    text-align: center;\n    h4 {\n    font-weight: bold;\n}\n  }\n</style>\n\n<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/\"></ion-back-button>\n    </ion-buttons>\n    <ion-title> Dettaglio Tariffa {{idSelected}} &nbsp;&nbsp;zone: {{zone_title}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid>\n    <ion-row >\n      <ion-col size= \"12\">\n        <div class=\"ion-text-center ion-text-uppercase bg_blu\"><h4>Titoli di viaggio occasionali</h4></div>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"12\" size-sm>\n        <ion-card >\n          <ion-card-header>\n            <ion-card-title>\n              <div class=\"ion-text-center ion-text-capitalize\">\n                {{information.ordinario.ord}} &euro;\n              </div>\n            </ion-card-title>\n          </ion-card-header>\n          <ion-card-content>\n              <div class=\"ion-text-center ion-text-capitalize\">\n                Ordinario\n              </div>\n          </ion-card-content>\n          </ion-card>\n      </ion-col>\n\n      <ion-col size=\"12\" size-sm>\n        <ion-card>\n          <ion-card-header>\n            <ion-card-title> \n              <div class=\"ion-text-center ion-text-capitalize\">\n                {{information.ordinario.giorn}} &euro;\n              </div>\n            </ion-card-title>\n          </ion-card-header>\n          <ion-card-content>\n            <div class=\"ion-text-center ion-text-capitalize\">\n              Giornaliero\n            </div>\n          </ion-card-content>\n        </ion-card>\n      </ion-col >\n\n      <ion-col size=\"12\" size-sm>\n        <ion-card>\n          <ion-card-header>\n            <div class=\"ion-text-center ion-text-capitalize\">           \n              <ion-card-title> {{information.ordinario.tregiorn}} &euro;</ion-card-title>\n            </div>\n          </ion-card-header>\n        <ion-card-content>\n          <div class=\"ion-text-center ion-text-capitalize\">   \n            3 giorni\n          </div>  \n        </ion-card-content>\n        </ion-card>\n      </ion-col>\n      </ion-row>\n\n\n      \n          \n          <ion-row >\n              <ion-col size= \"12\">\n                <div class=\"ion-text-center ion-text-uppercase bg_blu\"><h4>Abbonamenti ordinari</h4></div>\n              </ion-col>\n            </ion-row>\n            <ion-row>\n              <ion-col size=\"12\" size-sm>\n                <ion-card >\n                  <ion-card-header>\n                    <ion-card-title>\n                      <div class=\"ion-text-center ion-text-capitalize\">\n                        {{information.abbordinario.sett}} &euro;\n                      </div>\n                    </ion-card-title>\n                  </ion-card-header>\n                  <ion-card-content>\n                      <div class=\"ion-text-center ion-text-capitalize\">\n                        Settimanale\n                      </div>\n                  </ion-card-content>\n                  </ion-card>\n              </ion-col>\n        \n              <ion-col size=\"12\" size-sm>\n                <ion-card>\n                  <ion-card-header>\n                    <ion-card-title> \n                      <div class=\"ion-text-center ion-text-capitalize\">\n                        {{information.abbordinario.mensile}} &euro;\n                      </div>\n                    </ion-card-title>\n                  </ion-card-header>\n                  <ion-card-content>\n                    <div class=\"ion-text-center ion-text-capitalize\">\n                      Mensile\n                    </div>\n                  </ion-card-content>\n                </ion-card>\n              </ion-col >\n        \n              <ion-col size=\"12\" size-sm>\n                <ion-card>\n                  <ion-card-header>\n                    <div class=\"ion-text-center ion-text-capitalize\">           \n                      <ion-card-title> {{information.abbordinario.annuale}} &euro;</ion-card-title>\n                    </div>\n                  </ion-card-header>\n                <ion-card-content>\n                  <div class=\"ion-text-center ion-text-capitalize\">   \n                    Annuale\n                  </div>  \n                </ion-card-content>\n                </ion-card>\n              </ion-col>\n              </ion-row>\n               \n              <ion-row>\n                  <ion-col size= \"12\">\n                    <div class=\"ion-text-center ion-text-uppercase bg_blu\"><h4>Abbonamenti agevolati</h4></div>\n                  </ion-col>\n                </ion-row>\n\n              <ion-row *ngIf=\"idSelected=='1 (Urbano Milano)'\">\n                  <ion-col size= \"12\" size-sm>\n                      <ion-card>\n                          <ion-card-header>\n                            <ion-card-title> \n                              <div class=\"ion-text-center ion-text-capitalize\">\n                                <a href='https://nuovosistematariffario.atm.it/#agevolazioni' target=\"_blank\">  Guarda le agevolazioni in ambito urbano del Comune di Milano </a>\n                              </div>\n                            </ion-card-title>\n                          </ion-card-header>\n                      </ion-card>\n                  </ion-col>\n                </ion-row>\n\n          \n           \n                <ion-row *ngIf=\"idSelected!='1 (Urbano Milano)'\">\n                  <ion-col size=\"12\" size-sm>\n                    <ion-card >\n                      <ion-card-header>\n                        <ion-card-title>\n                          <div class=\"ion-text-center ion-text-capitalize\">\n                            {{information.abbagevolato.mensile}} &euro;\n                          </div>\n                        </ion-card-title>\n                      </ion-card-header>\n                      <ion-card-content>\n                          <div class=\"ion-text-center ion-text-capitalize\">\n                            Mensile under26 / over65\n                          </div>\n                      </ion-card-content>\n                      </ion-card>\n                  </ion-col>\n            \n                  <ion-col size=\"12\" size-sm>\n                    <ion-card>\n                      <ion-card-header>\n                        <ion-card-title> \n                          <div class=\"ion-text-center ion-text-capitalize\">\n                            {{information.abbagevolato.annuale}} &euro;\n                          </div>\n                        </ion-card-title>\n                      </ion-card-header>\n                      <ion-card-content>\n                        <div class=\"ion-text-center ion-text-capitalize\">\n                            Annuale under26 / over65\n\n                        </div>\n                      </ion-card-content>\n                    </ion-card>\n                  </ion-col >\n            \n                  <ion-col size=\"12\" size-sm>\n                    <ion-card>\n                      <ion-card-header>\n                        <div class=\"ion-text-center ion-text-capitalize\">           \n                          <ion-card-title> {{information.abbagevolato.annualeisee}} &euro;</ion-card-title>\n                        </div>\n                      </ion-card-header>\n                    <ion-card-content>\n                      <div class=\"ion-text-center ion-text-capitalize\">   \n                          Annuale ISEE < 6.000 &euro;\n                      </div>  \n                    </ion-card-content>\n                    </ion-card>\n                  </ion-col>\n                  </ion-row>\n                   \n\n\n\n\n  </ion-grid>\n\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/direction-details/direction-details.page.scss":
/*!*********************************************************************!*\
  !*** ./src/app/pages/direction-details/direction-details.page.scss ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".bg_blu {\n  background-color: #0070c0;\n  color: #ffffff; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2ZyYW5jby93b3Jrc3BhY2UvYXBwX3N0aWJtL3N0aWJtX2NsaWVudC9zdGlibV9jbGllbnQvc3JjL2FwcC9wYWdlcy9kaXJlY3Rpb24tZGV0YWlscy9kaXJlY3Rpb24tZGV0YWlscy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx5QkFBd0I7RUFDeEIsY0FBYSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvZGlyZWN0aW9uLWRldGFpbHMvZGlyZWN0aW9uLWRldGFpbHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJnX2JsdXtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiMwMDcwYzA7XG4gICAgY29sb3I6I2ZmZmZmZjtcbn1cbiJdfQ== */"

/***/ }),

/***/ "./src/app/pages/direction-details/direction-details.page.ts":
/*!*******************************************************************!*\
  !*** ./src/app/pages/direction-details/direction-details.page.ts ***!
  \*******************************************************************/
/*! exports provided: DirectionDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DirectionDetailsPage", function() { return DirectionDetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");

//import { DirectionService } from './../../services/direction.service';


var DirectionDetailsPage = /** @class */ (function () {
    /**
    * Constructor of our details page
    * @param activatedRoute Information about the route we are on
    */
    function DirectionDetailsPage(activatedRoute) {
        this.activatedRoute = activatedRoute;
        this.information = null;
        this.idSelected = null;
        this.zone_title = "";
        this.ticketInfo = {
            "1urb": {
                "ordinario": { "ord": "2,00", "giorn": "7,00", "tregiorn": "12,00" },
                "abbordinario": { "sett": "17,00", "mensile": "39,00", "annuale": "330,00" },
                "abbagevolato": { "mensile": "37,50", "annuale": "345,00", "annualeisee": "69,00" }
            },
            "1": {
                "ordinario": { "ord": "2,00", "giorn": "7,00", "tregiorn": "12,00" },
                "abbordinario": { "sett": "17,00", "mensile": "50,00", "annuale": "460,00" },
                "abbagevolato": { "mensile": "37,50", "annuale": "345,00", "annualeisee": "69,00" }
            },
            "2": { "ordinario": { "ord": "2,40", "giorn": "8,40", "tregiorn": "14,50" }, "abbordinario": { "sett": "20,50", "mensile": "60,00", "annuale": "552,00" }, "abbagevolato": { "mensile": "45,00", "annuale": "414,00", "annualeisee": "83,00" } },
            "3": { "ordinario": { "ord": "2,80", "giorn": "9,80", "tregiorn": "17,00" }, "abbordinario": { "sett": "24,00", "mensile": "70,00", "annuale": "644,00" }, "abbagevolato": { "mensile": "53,00", "annuale": "483,00", "annualeisee": "97,00" } },
            "4": { "ordinario": { "ord": "3,20", "giorn": "11,00", "tregiorn": "19,00" }, "abbordinario": { "sett": "27,00", "mensile": "77,00", "annuale": "682,00" }, "abbagevolato": { "mensile": "58,00", "annuale": "512,00", "annualeisee": "102,00" } },
            "5": { "ordinario": { "ord": "3,60", "giorn": "12,50", "tregiorn": "21,50" }, "abbordinario": { "sett": "30,50", "mensile": "82,00", "annuale": "712,00" }, "abbagevolato": { "mensile": "62,00", "annuale": "534,00", "annualeisee": "107,00" } },
            "6": { "ordinario": { "ord": "4,00", "giorn": "14,00", "tregiorn": "24,00" }, "abbordinario": { "sett": "34,00", "mensile": "87,00", "annuale": "738,00" }, "abbagevolato": { "mensile": "65,00", "annuale": "554,00", "annualeisee": "111,00" } },
            "7": { "ordinario": { "ord": "4,40", "giorn": "15,50", "tregiorn": "26,50" }, "abbordinario": { "sett": "37,50", "mensile": "87,00", "annuale": "761,00" }, "abbagevolato": { "mensile": "65,00", "annuale": "571,00", "annualeisee": "114,00" } },
            "8": { "ordinario": { "ord": "1,60", "giorn": "5,60", "tregiorn": "9,60" }, "abbordinario": { "sett": "13,50", "mensile": "40,00", "annuale": "368,00" }, "abbagevolato": { "mensile": "30,00", "annuale": "276,00", "annualeisee": "55,00" } },
            "9": { "ordinario": { "ord": "2,00", "giorn": "7,00", "tregiorn": "12,00" }, "abbordinario": { "sett": "17,00", "mensile": "50,00", "annuale": "460,00" }, "abbagevolato": { "mensile": "37,50", "annuale": "345,00", "annualeisee": "69,00" } },
            "10": { "ordinario": { "ord": "2,40", "giorn": "8,40", "tregiorn": "14,50" }, "abbordinario": { "sett": "20,50", "mensile": "60,00", "annuale": "552,00" }, "abbagevolato": { "mensile": "45,00", "annuale": "414,00", "annualeisee": "83,00" } },
            "11": { "ordinario": { "ord": "2,80", "giorn": "9,80", "tregiorn": "17,00" }, "abbordinario": { "sett": "24,00", "mensile": "70,00", "annuale": "644,00" }, "abbagevolato": { "mensile": "53,00", "annuale": "483,00", "annualeisee": "97,00" } },
            "12": { "ordinario": { "ord": "3,20", "giorn": "11,00", "tregiorn": "19,00" }, "abbordinario": { "sett": "27,00", "mensile": "77,00", "annuale": "682,00" }, "abbagevolato": { "mensile": "58,00", "annuale": "512,00", "annualeisee": "102,00" } },
            "13": { "ordinario": { "ord": "3,60", "giorn": "12,50", "tregiorn": "21,50" }, "abbordinario": { "sett": "30,50", "mensile": "82,00", "annuale": "712,00" }, "abbagevolato": { "mensile": "62,00", "annuale": "534,00", "annualeisee": "107,00" } },
            "14": { "ordinario": { "ord": "1,60", "giorn": "5,60", "tregiorn": "9,60" }, "abbordinario": { "sett": "13,50", "mensile": "40,00", "annuale": "368,00" }, "abbagevolato": { "mensile": "30,00", "annuale": "276,00", "annualeisee": "55,00" } },
            "15": { "ordinario": { "ord": "2,00", "giorn": "7,00", "tregiorn": "12,00" }, "abbordinario": { "sett": "17,00", "mensile": "50,00", "annuale": "460,00" }, "abbagevolato": { "mensile": "37,50", "annuale": "345,00", "annualeisee": "69,00" } },
            "16": { "ordinario": { "ord": "2,40", "giorn": "8,40", "tregiorn": "14,50" }, "abbordinario": { "sett": "20,50", "mensile": "60,00", "annuale": "552,00" }, "abbagevolato": { "mensile": "45,00", "annuale": "414,00", "annualeisee": "83,00" } },
            "17": { "ordinario": { "ord": "2,80", "giorn": "9,80", "tregiorn": "17,00" }, "abbordinario": { "sett": "24,00", "mensile": "70,00", "annuale": "644,00" }, "abbagevolato": { "mensile": "53,00", "annuale": "483,00", "annualeisee": "97,00" } },
            "18": { "ordinario": { "ord": "3,20", "giorn": "11,00", "tregiorn": "19,00" }, "abbordinario": { "sett": "27,00", "mensile": "77,00", "annuale": "682,00" }, "abbagevolato": { "mensile": "58,00", "annuale": "512,00", "annualeisee": "102,00" } },
            "19": { "ordinario": { "ord": "1,60", "giorn": "5,60", "tregiorn": "9,60" }, "abbordinario": { "sett": "13,50", "mensile": "40,00", "annuale": "368,00" }, "abbagevolato": { "mensile": "30,00", "annuale": "276,00", "annualeisee": "55,00" } },
            "20": { "ordinario": { "ord": "2,00", "giorn": "7,00", "tregiorn": "12,00" }, "abbordinario": { "sett": "17,00", "mensile": "50,00", "annuale": "460,00" }, "abbagevolato": { "mensile": "37,50", "annuale": "345,00", "annualeisee": "69,00" } },
            "21": { "ordinario": { "ord": "2,40", "giorn": "8,40", "tregiorn": "14,50" }, "abbordinario": { "sett": "20,50", "mensile": "60,00", "annuale": "552,00" }, "abbagevolato": { "mensile": "45,00", "annuale": "414,00", "annualeisee": "83,00" } },
            "22": { "ordinario": { "ord": "2,80", "giorn": "9,80", "tregiorn": "17,00" }, "abbordinario": { "sett": "24,00", "mensile": "70,00", "annuale": "644,00" }, "abbagevolato": { "mensile": "53,00", "annuale": "483,00", "annualeisee": "97,00" } },
            "23": { "ordinario": { "ord": "1,60", "giorn": "5,60", "tregiorn": "9,60" }, "abbordinario": { "sett": "13,50", "mensile": "40,00", "annuale": "368,00" }, "abbagevolato": { "mensile": "30,00", "annuale": "276,00", "annualeisee": "55,00" } },
            "24": { "ordinario": { "ord": "2,00", "giorn": "7,00", "tregiorn": "12,00" }, "abbordinario": { "sett": "17,00", "mensile": "50,00", "annuale": "460,00" }, "abbagevolato": { "mensile": "37,50", "annuale": "345,00", "annualeisee": "69,00" } },
            "25": { "ordinario": { "ord": "2,40", "giorn": "8,40", "tregiorn": "14,50" }, "abbordinario": { "sett": "20,50", "mensile": "60,00", "annuale": "552,00" }, "abbagevolato": { "mensile": "45,00", "annuale": "414,00", "annualeisee": "83,00" } },
            "26": { "ordinario": { "ord": "1,60", "giorn": "5,60", "tregiorn": "9,60" }, "abbordinario": { "sett": "13,50", "mensile": "40,00", "annuale": "368,00" }, "abbagevolato": { "mensile": "30,00", "annuale": "276,00", "annualeisee": "55,00" } },
            "27": { "ordinario": { "ord": "2,00", "giorn": "7,00", "tregiorn": "12,00" }, "abbordinario": { "sett": "17,00", "mensile": "50,00", "annuale": "460,00" }, "abbagevolato": { "mensile": "37,50", "annuale": "345,00", "annualeisee": "69,00" } },
            "28": { "ordinario": { "ord": "1,60", "giorn": "5,60", "tregiorn": "9,60" }, "abbordinario": { "sett": "13,50", "mensile": "40,00", "annuale": "368,00" }, "abbagevolato": { "mensile": "30,00", "annuale": "276,00", "annualeisee": "55,00" } }
        };
    }
    DirectionDetailsPage.prototype.ngOnInit = function () {
        // Get the ID that was passed with the URL
        var id_zone = this.activatedRoute.snapshot.paramMap.get('id');
        var arr = id_zone.split("_");
        var id = arr[0];
        this.zone_title = arr[1];
        this.idSelected = id;
        //alert("id: "+id);
        this.information = this.ticketInfo[id];
        /*
        // Get the information from the API
        this.movieService.getDetails(id).subscribe(result => {
          this.information = result;
        });*/
    };
    DirectionDetailsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-direction-details',
            template: __webpack_require__(/*! ./direction-details.page.html */ "./src/app/pages/direction-details/direction-details.page.html"),
            styles: [__webpack_require__(/*! ./direction-details.page.scss */ "./src/app/pages/direction-details/direction-details.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], DirectionDetailsPage);
    return DirectionDetailsPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-direction-details-direction-details-module.js.map