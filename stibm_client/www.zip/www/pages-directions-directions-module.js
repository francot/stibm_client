(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-directions-directions-module"],{

/***/ "../../../../node_modules/dateformat/lib/dateformat.js":
/*!**************************************************************!*\
  !*** /home/franco/node_modules/dateformat/lib/dateformat.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_RESULT__;/*
 * Date Format 1.2.3
 * (c) 2007-2009 Steven Levithan <stevenlevithan.com>
 * MIT license
 *
 * Includes enhancements by Scott Trenda <scott.trenda.net>
 * and Kris Kowal <cixar.com/~kris.kowal/>
 *
 * Accepts a date, a mask, or a date and a mask.
 * Returns a formatted version of the given date.
 * The date defaults to the current date/time.
 * The mask defaults to dateFormat.masks.default.
 */

(function(global) {
  'use strict';

  var dateFormat = (function() {
      var token = /d{1,4}|m{1,4}|yy(?:yy)?|([HhMsTt])\1?|[LloSZWN]|"[^"]*"|'[^']*'/g;
      var timezone = /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g;
      var timezoneClip = /[^-+\dA-Z]/g;
  
      // Regexes and supporting functions are cached through closure
      return function (date, mask, utc, gmt) {
  
        // You can't provide utc if you skip other args (use the 'UTC:' mask prefix)
        if (arguments.length === 1 && kindOf(date) === 'string' && !/\d/.test(date)) {
          mask = date;
          date = undefined;
        }
  
        date = date || new Date;
  
        if(!(date instanceof Date)) {
          date = new Date(date);
        }
  
        if (isNaN(date)) {
          throw TypeError('Invalid date');
        }
  
        mask = String(dateFormat.masks[mask] || mask || dateFormat.masks['default']);
  
        // Allow setting the utc/gmt argument via the mask
        var maskSlice = mask.slice(0, 4);
        if (maskSlice === 'UTC:' || maskSlice === 'GMT:') {
          mask = mask.slice(4);
          utc = true;
          if (maskSlice === 'GMT:') {
            gmt = true;
          }
        }
  
        var _ = utc ? 'getUTC' : 'get';
        var d = date[_ + 'Date']();
        var D = date[_ + 'Day']();
        var m = date[_ + 'Month']();
        var y = date[_ + 'FullYear']();
        var H = date[_ + 'Hours']();
        var M = date[_ + 'Minutes']();
        var s = date[_ + 'Seconds']();
        var L = date[_ + 'Milliseconds']();
        var o = utc ? 0 : date.getTimezoneOffset();
        var W = getWeek(date);
        var N = getDayOfWeek(date);
        var flags = {
          d:    d,
          dd:   pad(d),
          ddd:  dateFormat.i18n.dayNames[D],
          dddd: dateFormat.i18n.dayNames[D + 7],
          m:    m + 1,
          mm:   pad(m + 1),
          mmm:  dateFormat.i18n.monthNames[m],
          mmmm: dateFormat.i18n.monthNames[m + 12],
          yy:   String(y).slice(2),
          yyyy: y,
          h:    H % 12 || 12,
          hh:   pad(H % 12 || 12),
          H:    H,
          HH:   pad(H),
          M:    M,
          MM:   pad(M),
          s:    s,
          ss:   pad(s),
          l:    pad(L, 3),
          L:    pad(Math.round(L / 10)),
          t:    H < 12 ? dateFormat.i18n.timeNames[0] : dateFormat.i18n.timeNames[1],
          tt:   H < 12 ? dateFormat.i18n.timeNames[2] : dateFormat.i18n.timeNames[3],
          T:    H < 12 ? dateFormat.i18n.timeNames[4] : dateFormat.i18n.timeNames[5],
          TT:   H < 12 ? dateFormat.i18n.timeNames[6] : dateFormat.i18n.timeNames[7],
          Z:    gmt ? 'GMT' : utc ? 'UTC' : (String(date).match(timezone) || ['']).pop().replace(timezoneClip, ''),
          o:    (o > 0 ? '-' : '+') + pad(Math.floor(Math.abs(o) / 60) * 100 + Math.abs(o) % 60, 4),
          S:    ['th', 'st', 'nd', 'rd'][d % 10 > 3 ? 0 : (d % 100 - d % 10 != 10) * d % 10],
          W:    W,
          N:    N
        };
  
        return mask.replace(token, function (match) {
          if (match in flags) {
            return flags[match];
          }
          return match.slice(1, match.length - 1);
        });
      };
    })();

  dateFormat.masks = {
    'default':               'ddd mmm dd yyyy HH:MM:ss',
    'shortDate':             'm/d/yy',
    'mediumDate':            'mmm d, yyyy',
    'longDate':              'mmmm d, yyyy',
    'fullDate':              'dddd, mmmm d, yyyy',
    'shortTime':             'h:MM TT',
    'mediumTime':            'h:MM:ss TT',
    'longTime':              'h:MM:ss TT Z',
    'isoDate':               'yyyy-mm-dd',
    'isoTime':               'HH:MM:ss',
    'isoDateTime':           'yyyy-mm-dd\'T\'HH:MM:sso',
    'isoUtcDateTime':        'UTC:yyyy-mm-dd\'T\'HH:MM:ss\'Z\'',
    'expiresHeaderFormat':   'ddd, dd mmm yyyy HH:MM:ss Z'
  };

  // Internationalization strings
  dateFormat.i18n = {
    dayNames: [
      'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat',
      'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
    ],
    monthNames: [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
      'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'
    ],
    timeNames: [
      'a', 'p', 'am', 'pm', 'A', 'P', 'AM', 'PM'
    ]
  };

function pad(val, len) {
  val = String(val);
  len = len || 2;
  while (val.length < len) {
    val = '0' + val;
  }
  return val;
}

/**
 * Get the ISO 8601 week number
 * Based on comments from
 * http://techblog.procurios.nl/k/n618/news/view/33796/14863/Calculate-ISO-8601-week-and-year-in-javascript.html
 *
 * @param  {Object} `date`
 * @return {Number}
 */
function getWeek(date) {
  // Remove time components of date
  var targetThursday = new Date(date.getFullYear(), date.getMonth(), date.getDate());

  // Change date to Thursday same week
  targetThursday.setDate(targetThursday.getDate() - ((targetThursday.getDay() + 6) % 7) + 3);

  // Take January 4th as it is always in week 1 (see ISO 8601)
  var firstThursday = new Date(targetThursday.getFullYear(), 0, 4);

  // Change date to Thursday same week
  firstThursday.setDate(firstThursday.getDate() - ((firstThursday.getDay() + 6) % 7) + 3);

  // Check if daylight-saving-time-switch occurred and correct for it
  var ds = targetThursday.getTimezoneOffset() - firstThursday.getTimezoneOffset();
  targetThursday.setHours(targetThursday.getHours() - ds);

  // Number of weeks between target Thursday and first Thursday
  var weekDiff = (targetThursday - firstThursday) / (86400000*7);
  return 1 + Math.floor(weekDiff);
}

/**
 * Get ISO-8601 numeric representation of the day of the week
 * 1 (for Monday) through 7 (for Sunday)
 * 
 * @param  {Object} `date`
 * @return {Number}
 */
function getDayOfWeek(date) {
  var dow = date.getDay();
  if(dow === 0) {
    dow = 7;
  }
  return dow;
}

/**
 * kind-of shortcut
 * @param  {*} val
 * @return {String}
 */
function kindOf(val) {
  if (val === null) {
    return 'null';
  }

  if (val === undefined) {
    return 'undefined';
  }

  if (typeof val !== 'object') {
    return typeof val;
  }

  if (Array.isArray(val)) {
    return 'array';
  }

  return {}.toString.call(val)
    .slice(8, -1).toLowerCase();
};



  if (true) {
    !(__WEBPACK_AMD_DEFINE_RESULT__ = (function () {
      return dateFormat;
    }).call(exports, __webpack_require__, exports, module),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  } else {}
})(this);


/***/ }),

/***/ "./src/app/pages/directions/directions.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/directions/directions.module.ts ***!
  \*******************************************************/
/*! exports provided: DirectionsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DirectionsPageModule", function() { return DirectionsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _directions_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./directions.page */ "./src/app/pages/directions/directions.page.ts");
/* harmony import */ var ionic4_auto_complete__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ionic4-auto-complete */ "./node_modules/ionic4-auto-complete/index.js");







//import { SimpleFunctionModule } from 'src/app/components/simple-function/simple-function.module';

var routes = [
    {
        path: '',
        component: _directions_page__WEBPACK_IMPORTED_MODULE_6__["DirectionsPage"]
    }
];
var DirectionsPageModule = /** @class */ (function () {
    function DirectionsPageModule() {
    }
    DirectionsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                //SimpleFunctionModule,
                ionic4_auto_complete__WEBPACK_IMPORTED_MODULE_7__["AutoCompleteModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_directions_page__WEBPACK_IMPORTED_MODULE_6__["DirectionsPage"]]
        })
    ], DirectionsPageModule);
    return DirectionsPageModule;
}());



/***/ }),

/***/ "./src/app/pages/directions/directions.page.html":
/*!*******************************************************!*\
  !*** ./src/app/pages/directions/directions.page.html ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n\n\n\n  <ion-grid> \n      <ion-row>\n          <ion-col size=\"12\">\n            <ion-auto-complete \n            [multi]=\"false\"\n            [dataProvider]=\"suggestService\"\n            [disabled]=\"false\"\n            [options]=\"originOptions\"\n            (itemSelected)=\"originSelected($event)\"></ion-auto-complete>\n          </ion-col>\n          \n      </ion-row>\n      <ion-row>\n          \n          <ion-col size=\"12\">\n            <ion-auto-complete \n            [multi]=\"false\"\n            [dataProvider]=\"suggestService\"\n            [disabled]=\"false\"\n            [options]=\"destinationOptions\"\n            (itemSelected)=\"destinationSelected($event)\"></ion-auto-complete>\n          </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col  size=\"12\" size-sm>\n            <ion-item >\n                <ion-label style= \"color: darkgray\">Data/Ora Inizio Viaggio</ion-label>\n                <ion-datetime (ionChange)=\"dataChanged()\" display-format=\"DD/MM/YYYY HH:mm\" [(ngModel)]=\"dataString\"  [min]=\"this.getCurrDate()\" placeholder=\"Seleziona una data\"></ion-datetime>\n              </ion-item>\n              \n        </ion-col>\n        <!--\n        <ion-col  size=\"12\" size-sm>\n            <ion-item>\n                <ion-label style= \"color: darkgray\">Ora Inizio Viaggio</ion-label>\n                <ion-datetime [(ngModel)]=\"oraString\" display-format=\"HH:mm\" [min]=\"this.getCurrDate()\"></ion-datetime>\n            </ion-item>\n        </ion-col>\n      -->\n      </ion-row>\n      <ion-row>\n          <ion-col  size=\"12\">\n              <ion-button expand=\"block\" [disabled]='this.originString == null || this.destinationString == null' (click)=\"runSearch()\">Calcola Tariffa</ion-button>\n            </ion-col>\n      </ion-row>\n  </ion-grid> \n\n  \n\n<!--  \n   <ion-button  [routerLink]=\"['/directions/2']\">test</ion-button> \n   -->\n\n\n\n<!--    START LIST  -->\n\n<ion-card *ngFor=\"let result of results\" >\n    <ion-card-header>\n        \n        <ion-card-title *ngIf =\" result.fare.price < 90\"    >  \n<ion-item [routerLink]=\"['/','directions', result.fare.id +'_'+ result.fare.zone_id]\">    \n  <ion-label text-wrap>        \n    <div class=\"ion-text-end\"> \n                <ion-text color=\"primary\">\n\n         <strong> TARIFFA {{result.fare.id}} </strong> &nbsp;\n            zone {{result.fare.zone_id}}  &nbsp; \n            {{result.fare.price}}&euro; vale {{result.fare.duration}}'&nbsp;          \n\n            </ion-text>\n          </div>\n          <div *ngFor=\"let color of result.fare.zone_color\" [ngStyle]=\"getColorZone(color)\"  align-self-end>\n              &nbsp;&nbsp;\n    </div>\n  </ion-label>\n          <ion-icon size=\"large\" name=\"arrow-dropright\"></ion-icon> \n\n        </ion-item>\n\n        </ion-card-title>\n\n        <ion-card-title *ngIf =\" result.fare.price === 90\"    >  \n          <ion-item >    \n            <ion-label text-wrap>        \n              <div class=\"ion-text-start\"> \n                          <ion-text color=\"danger\">\n                     <strong>TARIFFA</strong> non determinabile per indisponibilità di dati &nbsp;\n                      </ion-text>\n                    </div>\n            </ion-label>\n                  </ion-item>\n                  </ion-card-title>\n\n                  <ion-card-title *ngIf =\" result.fare.price > 90\"    >  \n                    <ion-item >    \n                      <ion-label text-wrap>        \n                        <div class=\"ion-text-start\"> \n                                    <ion-text color=\"danger\">\n                                      <strong>TARIFFA</strong> non determinabile perchè il viaggio comprende servizi non integrati nello STIBM &nbsp;\n                                    </ion-text>\n                              </div>\n                      </ion-label>\n                            </ion-item>\n                            </ion-card-title>\n\n\n\n\n      </ion-card-header>\n  <ion-card-content>\n      <ion-grid>\n        <ion-row text-wrap>\n              <ion-col size=\"12\" size-sm=\"9\">\n                <ion-list>\n                  <ion-item no-padding *ngFor=\"let step of result.steps; let i = index\" >\n\n                    <div style=\"\n                    float: left;\n                    width:auto;\n                    min-width: 80px !important; \n                    \">\n                        <ion-img style=\"width:30px; float:left\" *ngIf=\"step.line.vehicle.local_icon != null\" src=\"{{step.line.vehicle.local_icon}}\"></ion-img>\n                        <ion-img style=\"width:30px; float:left\" *ngIf=\"step.line.vehicle.local_icon == null && step.line.vehicle.icon != null\" src=\"{{step.line.vehicle.icon}}\"></ion-img>\n                        <ion-button  fill=\"outline\" small style=\"float:left; margin-top: 2px;\" disabled = True> {{step.line.short_name}}  </ion-button>\n                    </div>\n                    \n                    <ion-grid>\n                      <ion-row>\n                        <ion-col size=\"12\" size-sm=\"7\">\n                          <ion-text color=\"dark\">\n                            <h6> {{step.departure_stop.name}} ({{step.departure_time.text}}) <br>  \n                              {{step.arrival_stop.name}} ({{step.arrival_time.text}})<br> \n                              ({{step.num_stops}} fermate) \n                            </h6>  \n                          </ion-text>\n                        </ion-col>\n\n\n                        <ion-col size=\"12\" size-sm=\"5\">\n                            <ion-badge   onMouseOver=\"this.style.color= '#F5F5F5'\" onMouseOut=\"this.style.color='#FFFFFF'\"  style=\"cursor: pointer;\" color=\"secondary\" (click)=\"agencyurlClicked(step.line.agencies[0].url)\" >{{step.line.agencies[0].name}}</ion-badge>\n                           <!--> href=\"{{step.line.agencies[0].url}}\"<-->\n                          </ion-col>\n\n                      </ion-row>\n                    </ion-grid>\n\n                    \n                  </ion-item>\n                </ion-list>\n              </ion-col>\n              <ion-col align-self-center size=\"12\"  size-sm=\"3\">            \n                {{result.departure_time.text}}   <ion-icon name=\"ios-arrow-forward\">  </ion-icon> {{result.arrival_time.text}} \n                <br> \n                Durata: {{(result.duration.value/60 | number:'1.0-0')}}'  \n              </ion-col>\n        </ion-row>\n      </ion-grid>\n\n                 <!--  <ion-button fill=\"outline\" slot=\"end\">View</ion-button>  -->\n\n                <!--  \n\n      <ion-grid [routerLink]=\"['/','directions', result.fare.id]\">\n          <ion-row text-wrap>\n            <ion-col size=12 >\n      \n                \n              <div class=\"ion-text-end\"> \n      \n                  <ion-text color=\"primary\">\n                    \n                        <h2>\n                          <a href=\"javascript:;\">\n                            <strong>TARIFFA {{result.fare.id}}</strong>&nbsp;zone {{result.fare.zone_id}}  &nbsp; {{result.fare.price}}&euro; vale {{result.fare.duration}}'  &nbsp; \n                            <ion-icon size=\"large\" name=\"arrow-dropright\"></ion-icon> \n                          </a>\n                          </h2>\n                  </ion-text>\n              </div>\n              <div *ngFor=\"let color of result.fare.zone_color\" [ngStyle]=\"getColorZone(color)\"  align-self-end>\n                  &nbsp;&nbsp;\n              </div>\n            </ion-col>\n\n          </ion-row>\n        </ion-grid>\n      --> \n\n  </ion-card-content>\n\n  \n</ion-card>\n\n\n"

/***/ }),

/***/ "./src/app/pages/directions/directions.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/pages/directions/directions.page.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-auto-complete {\n  width: 100%; }\n\n.stepList {\n  border: solid 1px #ddd;\n  padding: 5px;\n  border-radius: 5px;\n  text-align: left;\n  font-size: 12pt; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2ZyYW5jby93b3Jrc3BhY2UvYXBwX3N0aWJtL3N0aWJtX2NsaWVudC9zdGlibV9jbGllbnQvc3JjL2FwcC9wYWdlcy9kaXJlY3Rpb25zL2RpcmVjdGlvbnMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBVyxFQUFBOztBQUdmO0VBRUksc0JBQXNCO0VBQ3RCLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLGVBQWUsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2RpcmVjdGlvbnMvZGlyZWN0aW9ucy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tYXV0by1jb21wbGV0ZSB7XG4gICAgd2lkdGg6IDEwMCU7XG59XG5cbi5zdGVwTGlzdFxue1xuICAgIGJvcmRlcjogc29saWQgMXB4ICNkZGQ7XG4gICAgcGFkZGluZzogNXB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGZvbnQtc2l6ZTogMTJwdDtcbn1cblxuIl19 */"

/***/ }),

/***/ "./src/app/pages/directions/directions.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/directions/directions.page.ts ***!
  \*****************************************************/
/*! exports provided: DirectionsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DirectionsPage", function() { return DirectionsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_suggest_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/suggest.service */ "./src/app/services/suggest.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");







var DirectionsPage = /** @class */ (function () {
    //url = 'http://www.fantacb.com/data.php?';
    function DirectionsPage(http, router, loadingController, suggestService, alertController) {
        this.http = http;
        this.router = router;
        this.loadingController = loadingController;
        this.suggestService = suggestService;
        this.alertController = alertController;
        this.results = [];
        this.originString = null;
        this.destinationString = null;
        this.zonaOrigin = null;
        this.zonaIdOrigin = null;
        //private now = new Date().toISOString();
        this.now = new Date();
        this.dataString = "";
        this.oraString = "";
        this.originOptions = {
            autocomplete: 'on',
            placeholder: 'Comune di Partenza',
            type: 'search'
        };
        this.destinationOptions = {
            autocomplete: 'on',
            placeholder: 'Comune di Arrivo',
            type: 'search'
        };
        this.url = 'https://europe-west1-stibm-1561387563826.cloudfunctions.net/';
    }
    DirectionsPage.prototype.ngOnInit = function () {
        this.dataString = this.getCurrDate();
        this.oraString = this.getCurrDate();
    };
    DirectionsPage.prototype.dataChanged = function () {
        this.oraString = this.dataString;
        //    console.log(this.oraString);
    };
    DirectionsPage.prototype.getCurrDate = function () {
        var dateFormat = __webpack_require__(/*! dateformat */ "../../../../node_modules/dateformat/lib/dateformat.js");
        var ret = "";
        var data = dateFormat(this.now, "yyyy-mm-dd");
        var ora = dateFormat(this.now, "HH:MM:ss.lo");
        ora = ora.replace(/00$/, ":00");
        ret = data + "T" + ora;
        return ret;
    };
    DirectionsPage.prototype.runSearch = function () {
        var _this = this;
        if (this.originString != null && this.destinationString != null) {
            if (this.originString == 'Milano' && this.destinationString == 'Milano') {
                this.router.navigate(['/', 'directions', '1urb_UrbanoMilano']);
            }
            else if (this.originString == this.destinationString) {
                this.router.navigate(['/', 'directions', this.zonaOrigin + '_' + this.zonaIdOrigin]);
            }
            else {
                //let datetime = this.dataString+"|"+this.oraString;
                var datetime = this.dataString;
                var urlRequest = this.url + "get_directions_data?origin=" + encodeURI(this.originString) + "&destination=" + encodeURI(this.destinationString) + "&departure_time=" + encodeURI(datetime);
                urlRequest = urlRequest.replace("+", "PLUS");
                //console.log("URL: ", urlRequest);
                //return;
                this.presentLoading();
                this.http.get(urlRequest)
                    .subscribe(function (res) {
                    _this.results = res;
                    _this.dismissLoading();
                    if (_this.results == null || _this.results.length == 0) {
                        _this.presentAlert();
                    }
                }, function (error) {
                    setTimeout(function () {
                        //alert("Errore");
                        _this.results = [];
                        _this.dismissLoading();
                        _this.presentAlert();
                    }, 1000);
                });
            }
        }
    };
    DirectionsPage.prototype.getStyleRow = function (step) {
        /*
        if (i % 2 == 0) {
          return {'background-color':'red', 'color':'yellow'};
        } else {
          return {'background-color':'yellow', 'color':'red'};
        }*/
        return {};
    };
    DirectionsPage.prototype.getColorZone = function (colorZone) {
        /*
        if (i % 2 == 0) {
          return {'background-color':'red', 'color':'yellow'};
        } else {
          return {'background-color':'yellow', 'color':'red'};
        }*/
        return { 'background-color': colorZone,
            'margin': '2px',
            'float': 'right',
            'width': '20px',
            'heigth': '20px'
        };
    };
    DirectionsPage.prototype.originSelected = function (item) {
        this.originString = item[this.suggestService.labelAttribute];
        this.zonaOrigin = item['zona'];
        this.zonaIdOrigin = item['zona_id'];
    };
    DirectionsPage.prototype.destinationSelected = function (item) {
        this.destinationString = item[this.suggestService.labelAttribute];
        this.zonaOrigin = item['zona'];
        this.zonaIdOrigin = item['zona_id'];
    };
    DirectionsPage.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _a;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _a = this;
                        return [4 /*yield*/, this.loadingController.create()];
                    case 1:
                        _a.loading = _b.sent();
                        this.loading.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    DirectionsPage.prototype.dismissLoading = function () {
        this.loading.dismiss();
    };
    DirectionsPage.prototype.agencyurlClicked = function (url) {
        window.open(url, '_system');
    };
    DirectionsPage.prototype.mouseoverAgency = function () {
        console.log("mouse");
    };
    DirectionsPage.prototype.presentAlert = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Impossibile calcolare la tariffa',
                            /*
                        subHeader: 'risultati',
                        */
                            message: 'Dati non disponibili per l\'origine/destinazione selezionata ',
                            buttons: ['OK']
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    DirectionsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-directions',
            template: __webpack_require__(/*! ./directions.page.html */ "./src/app/pages/directions/directions.page.html"),
            styles: [__webpack_require__(/*! ./directions.page.scss */ "./src/app/pages/directions/directions.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _services_suggest_service__WEBPACK_IMPORTED_MODULE_2__["SuggestService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]])
    ], DirectionsPage);
    return DirectionsPage;
}());



/***/ }),

/***/ "./src/app/services/suggest.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/suggest.service.ts ***!
  \*********************************************/
/*! exports provided: SuggestService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuggestService", function() { return SuggestService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var SuggestService = /** @class */ (function () {
    function SuggestService() {
        this.labelAttribute = 'name';
        this.objects = [
            { name: 'Milano', zona: 1 },
            { name: 'Milano Linate Aeroporto', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Milano Cascina Gobba M2', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Rho Fiera Milano M1', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'San Donato M3', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Sesto Marelli M1', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Cinisello Monza Bettola', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Abbiategrasso', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Agrate Brianza', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Aicurzio', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Albairate', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Albiate', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Arconate', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Arcore', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Arese', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Arluno', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Assago', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Baranzate', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Bareggio', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Barlassina', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Basiano', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Basiglio', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Bellinzago Lombardo', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Bellusco', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Bernareggio', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Bernate Ticino', zona: 26, zona_id: 'mi7-mi8' },
            { name: 'Besana in Brianza', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Besate', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Biassono', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Binasco', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Boffalora sopra Ticino', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Bollate', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Bovisio-Masciago', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Bregnano', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Bresso', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Briosco', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Brugherio', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Bubbiano', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Buccinasco', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Burago di Molgora', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Buscate', zona: 26, zona_id: 'mi7-mi8' },
            { name: 'Busnago', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Bussero', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Busto Arsizio', zona: 26, zona_id: 'mi7-mi8' },
            { name: 'Busto Garolfo', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Cabiate', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Calusco d\'Adda', zona: 26, zona_id: 'mi7-mi8' },
            { name: 'Calvignasco', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Cambiago', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Camparada', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Canegrate', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Cantù', zona: 26, zona_id: 'mi7-mi8' },
            { name: 'Caponago', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Carate Brianza', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Carimate', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Carnate', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Caronno Pertusella', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Carpiano', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Carugate', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Casalmaiocco', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Casarile', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Casatenovo', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Casorate Primo', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Casorezzo', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Cassano d\'Adda', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Cassina de\' Pecchi', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Cassinetta di Lugagnano', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Castano Primo', zona: 28, zona_id: 'mi8-mi9' },
            { name: 'Castellanza', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Cavenago di Brianza', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Ceriano Laghetto', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Cermenate', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Cernusco Lombardone', zona: 26, zona_id: 'mi7-mi8' },
            { name: 'Cernusco sul Naviglio', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Cerro al Lambro', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Cerro Maggiore', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Cesano Boscone', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Cesano Maderno', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Cesate', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Cinisello Balsamo', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Cisliano', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Cogliate', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Cologno Monzese', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Colturano', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Comazzo', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Concorezzo', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Corbetta', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Cormano', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Cornaredo', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Cornate d\'Adda', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Correzzana', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Corsico', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Cuggiono', zona: 26, zona_id: 'mi7-mi8' },
            { name: 'Cusago', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Cusano Milanino', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Dairago', zona: 26, zona_id: 'mi7-mi8' },
            { name: 'Desio', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Dresano', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Figino Serenza', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Gaggiano', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Garbagnate Milanese', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Gessate', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Giussano', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Gorgonzola', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Grezzago', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Gudo Visconti', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Inveruno', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Inzago', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Lacchiarella', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Lainate', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Lazzate', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Legnano', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Lentate sul Seveso', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Lesmo', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Limbiate', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Liscate', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Lissone', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Locate di Triulzi', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Macherio', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Magenta', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Magnago', zona: 28, zona_id: 'mi8-mi9' },
            { name: 'Marcallo con Casone', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Mariano Comense', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Masate', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Meda', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Mediglia', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Melegnano', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Melzo', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Merate', zona: 26, zona_id: 'mi7-mi8' },
            { name: 'Merlino', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Mesero', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Mezzago', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Misinto', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Monticello Brianza', zona: 26, zona_id: 'mi7-mi8' },
            { name: 'Monza', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Morimondo', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Motta Visconti', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Muggiò', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Mulazzano', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Nerviano', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Nosate', zona: 28, zona_id: 'mi8-mi9' },
            { name: 'Nova Milanese', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Novate Milanese', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Novedrate', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Noviglio', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Olgiate Molgora', zona: 26, zona_id: 'mi7-mi8' },
            { name: 'Opera', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Origgio', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Ornago', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Osnago', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Ossona', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Ozzero', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Paderno d\'Adda', zona: 26, zona_id: 'mi7-mi8' },
            { name: 'Paderno Dugnano', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Pantigliate', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Parabiago', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Paullo', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Pero', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Peschiera Borromeo', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Pessano con Bornago', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Pieve Emanuele', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Pioltello', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Pogliano Milanese', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Pozzo d\'Adda', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Pozzuolo Martesana', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Pregnana Milanese', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Renate', zona: 26, zona_id: 'mi7-mi8' },
            { name: 'Rescaldina', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Rho', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Robbiate', zona: 26, zona_id: 'mi7-mi8' },
            { name: 'Robecchetto con Induno', zona: 28, zona_id: 'mi8-mi9' },
            { name: 'Robecco sul Naviglio', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Rodano', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Roncello', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Ronco Briantino', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Rosate', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Rovellasca', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Rozzano', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'San Donato Milanese', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'San Giorgio su Legnano', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'San Giuliano Milanese', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Santo Stefano Ticino', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'San Vittore Olona', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'San Zenone al Lambro', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Saronno', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Sedriano', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Segrate', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Senago', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Seregno', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Sesto San Giovanni', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Settala', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Settimo Milanese', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Seveso', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Solaro', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Sordio', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Sovico', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Sulbiate', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Tavazzano con Villavesco', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Treviglio', zona: 26, zona_id: 'mi7-mi8' },
            { name: 'Trezzano Rosa', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Trezzano sul Naviglio', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Trezzo sull\'Adda', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Tribiano', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Triuggio', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Truccazzano', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Turbigo', zona: 28, zona_id: 'mi8-mi9' },
            { name: 'Uboldo', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Usmate Velate', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Vanzaghello', zona: 28, zona_id: 'mi8-mi9' },
            { name: 'Vanzago', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Vaprio d\'Adda', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Varedo', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Vedano al Lambro', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Veduggio con Colzano', zona: 26, zona_id: 'mi7-mi8' },
            { name: 'Verano Brianza', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Verderio', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Vermezzo', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Vernate', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Vignate', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Villa Cortese', zona: 23, zona_id: 'mi6-mi7' },
            { name: 'Villasanta', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Vimercate', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Vimodrone', zona: 8, zona_id: 'mi3-mi4' },
            { name: 'Vittuone', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Vizzolo Predabissi', zona: 14, zona_id: 'mi4-mi5' },
            { name: 'Zelo Buon Persico', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Zelo Surrigone', zona: 19, zona_id: 'mi5-mi6' },
            { name: 'Zibido San Giacomo', zona: 8, zona_id: 'mi3-mi4' }
        ];
    }
    SuggestService.prototype.getResults = function (keyword) {
        var _this = this;
        keyword = keyword.toLowerCase();
        return this.objects.filter(function (object) {
            var value = object[_this.labelAttribute].toLowerCase();
            return value.includes(keyword);
        });
    };
    SuggestService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], SuggestService);
    return SuggestService;
}());



/***/ })

}]);
//# sourceMappingURL=pages-directions-directions-module.js.map